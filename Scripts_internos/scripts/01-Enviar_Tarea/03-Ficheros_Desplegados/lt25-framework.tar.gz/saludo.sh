#. ./framework_config.sh
#. ./framework_config_interna.sh

echo "hola" > frikada.txt

